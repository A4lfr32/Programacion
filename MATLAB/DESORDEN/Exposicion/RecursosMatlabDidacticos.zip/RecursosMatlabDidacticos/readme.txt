TrayectoriaCartesianaAarticulacion.mlx
Traduce o mapea, puntos desde el Espacio cartesiano al Espacio de configuraci�n.

TrayectoriaSplineMatlab.mlx
Aplica la funci�n de matlab para Spline c�bico, obteniendo los angulos respectivos, y graficando en posici�n,
velocidad y aceleraci�n respecto al tiempo.

spline3_theta1.mlx
Aplica el metodo matricial para Spline c�bico, obteniendo los angulos respectivos, y graficando en posici�n,
velocidad y aceleraci�n respecto al tiempo.

spline3_theta2.mlx
Aplica el metodo matricial para Spline c�bico, obteniendo los angulos respectivos, y graficando en posici�n,
velocidad y aceleraci�n respecto al tiempo.

spline5_theta1.mlx
Aplica el metodo matricial para Spline de orden 5, obteniendo los angulos respectivos, y graficando en posici�n,
velocidad y aceleraci�n respecto al tiempo.

spline5_theta2.mlx
Aplica el metodo matricial para Spline de orden 5, obteniendo los angulos respectivos, y graficando en posici�n,
velocidad y aceleraci�n respecto al tiempo.

Graficar.m
Segun las opciones; 1, 2 o 3. Se grafica lo obtenido respectivamente en 
1)
TrayectoriaSplineMatlab.mlx
2)
spline3_theta1.mlx
spline3_theta2.mlx
3)
spline5_theta1.mlx
spline5_theta2.mlx


